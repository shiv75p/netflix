# Netflix-Homepage
 Internship task-2 :- A simple website having similar homepage of netflix using HTML and CSS.
